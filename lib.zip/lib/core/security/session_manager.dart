import 'package:flutter/foundation.dart';
import 'package:cryptography/cryptography.dart';
import '../../database/app_database.dart';
import '../crypto/crypto_service.dart';

class SessionManager extends ChangeNotifier {
  SessionManager(this.database, this.crypto);
  final AppDatabase database;
  final CryptoService crypto;

  SecretKey? _vaultKey;
  bool hasVault = false;

  bool get isUnlocked => _vaultKey != null;
  SecretKey get vaultKey => _vaultKey!;

  Future<void> initialize() async {
    hasVault = await database.hasVault();
    notifyListeners();
  }

  Future<void> createVault(String password) async {
    if (password.length < 10)
      throw StateError('Use at least 10 characters for the master password.');
    final derived = await crypto.derivePasswordKey(password);
    final verifier = await crypto.encryptString(
      'OFFLINE_VAULT_VERIFIER_V1',
      derived.key,
    );
    await database.createVaultMeta(
      salt: derived.salt,
      verifierCiphertext: verifier.bytes,
      verifierNonce: verifier.nonce,
      verifierMac: verifier.mac,
    );
    _vaultKey = derived.key;
    hasVault = true;
    notifyListeners();
  }

  Future<void> unlock(String password) async {
    final meta = await database.getVaultMeta();

    if (meta == null) {
      throw StateError('Vault metadata is missing.');
    }

    final derived = await crypto.derivePasswordKey(
      password,
      salt: Uint8List.fromList(meta.salt),
    );

    try {
      await crypto.decryptString(
        EncryptedPayload(
          bytes: Uint8List.fromList(meta.verifierCiphertext),
          nonce: Uint8List.fromList(meta.verifierNonce),
          mac: Uint8List.fromList(meta.verifierMac),
        ),
        derived.key,
      );
    } catch (_) {
      throw StateError('Incorrect master password.');
    }

    _vaultKey = derived.key;
    notifyListeners();
  }

  void lock() {
    _vaultKey = null;
    notifyListeners();
  }
}
