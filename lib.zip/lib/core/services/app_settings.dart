
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class AppSettings extends ChangeNotifier {
  AppSettings(this._storage);

  final FlutterSecureStorage _storage;
  int _autoLockMinutes = 5;
  bool _darkMode = false;

  int get autoLockMinutes => _autoLockMinutes;
  bool get darkMode => _darkMode;

  static Future<AppSettings> load() async {
    const storage = FlutterSecureStorage();
    final settings = AppSettings(storage);
    final lockValue = await storage.read(key: 'auto_lock_minutes');
    final darkValue = await storage.read(key: 'dark_mode');
    settings._autoLockMinutes = int.tryParse(lockValue ?? '') ?? 5;
    settings._darkMode = darkValue == 'true';
    return settings;
  }

  Future<void> setAutoLockMinutes(int value) async {
    _autoLockMinutes = value;
    await _storage.write(key: 'auto_lock_minutes', value: value.toString());
    notifyListeners();
  }

  Future<void> setDarkMode(bool value) async {
    _darkMode = value;
    await _storage.write(key: 'dark_mode', value: value.toString());
    notifyListeners();
  }
}
