
import 'package:flutter/material.dart';
import 'package:heroicons/heroicons.dart';

import '../../../core/services/app_container.dart';

class SettingsPanel extends StatelessWidget {
  const SettingsPanel({super.key, required this.container});
  final AppContainer container;

  @override
  Widget build(BuildContext context) {
    final settings = container.settings;
    const lockOptions = <int, String>{
      1: '1 minute',
      5: '5 minutes',
      15: '15 minutes',
      30: '30 minutes',
      0: 'Never automatically',
    };

    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) => ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('Preferences', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text(
            'Personalise how Sephiri protects and displays your vault.',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant),
          ),
          const SizedBox(height: 20),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      HeroIcon(HeroIcons.shieldCheck),
                      SizedBox(width: 10),
                      Text('Security', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
                    ],
                  ),
                  const SizedBox(height: 18),
                  DropdownButtonFormField<int>(
                    initialValue: lockOptions.containsKey(settings.autoLockMinutes) ? settings.autoLockMinutes : 5,
                    decoration: const InputDecoration(
                      labelText: 'Auto-lock after app is in background',
                      prefixIcon: Padding(padding: EdgeInsets.all(14), child: HeroIcon(HeroIcons.clock)),
                    ),
                    items: lockOptions.entries
                        .map((entry) => DropdownMenuItem(value: entry.key, child: Text(entry.value)))
                        .toList(),
                    onChanged: (value) {
                      if (value != null) settings.setAutoLockMinutes(value);
                    },
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'The vault will not lock when you briefly switch apps. The timer starts only after the app enters the background.',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: container.session.lock,
                      icon: const HeroIcon(HeroIcons.lockClosed),
                      label: const Text('Lock vault now'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: SwitchListTile(
              secondary: const HeroIcon(HeroIcons.moon),
              title: const Text('Dark appearance'),
              subtitle: const Text('Use a darker interface throughout the app.'),
              value: settings.darkMode,
              onChanged: settings.setDarkMode,
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Row(
                    children: [
                      HeroIcon(HeroIcons.circleStack),
                      SizedBox(width: 10),
                      Text('Local protection', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
                    ],
                  ),
                  SizedBox(height: 14),
                  _InfoRow(label: 'Storage', value: 'Local SQLite database'),
                  _InfoRow(label: 'Key derivation', value: 'Argon2id'),
                  _InfoRow(label: 'Encryption', value: 'XChaCha20-Poly1305'),
                  _InfoRow(label: 'Network access', value: 'No account or sync server'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        children: [
          Expanded(child: Text(label, style: Theme.of(context).textTheme.bodyMedium)),
          Flexible(child: Text(value, textAlign: TextAlign.end, style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600))),
        ],
      ),
    );
  }
}
