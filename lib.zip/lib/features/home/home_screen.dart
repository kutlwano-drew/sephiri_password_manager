import 'package:flutter/material.dart';
import 'package:heroicons/heroicons.dart';

import '../../core/services/app_container.dart';
import '../../core/services/password_health_service.dart';
import '../../core/services/vault_service.dart';
import '../../models/vault_entry.dart';
import '../../widgets/layout/app_scaffold.dart';
import '../backup/backup_screen.dart';
import '../entry/entry_editor_screen.dart';
import '../generator/generator_screen.dart';
import '../settings/settings_screen.dart';
import 'widgets/entry_tile.dart';
import 'widgets/password_health_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.container});
  final AppContainer container;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late final VaultService vault;
  final health = PasswordHealthService();
  final searchController = TextEditingController();
  String query = '';

  @override
  void initState() {
    super.initState();
    vault = VaultService(
      database: widget.container.database,
      crypto: widget.container.crypto,
      keyProvider: () => widget.container.session.vaultKey,
    );
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> add() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            EntryEditorScreen(container: widget.container, vault: vault),
      ),
    );
  }

  Future<void> edit(VaultEntryModel entry) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => EntryEditorScreen(
          container: widget.container,
          vault: vault,
          entry: entry,
        ),
      ),
    );
  }

  Future<void> _delete(VaultEntryModel entry) async {
    final id = entry.id;
    if (id == null) return;
    await vault.delete(id);
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('${entry.title} deleted')));
    }
  }

  @override
  Widget build(BuildContext context) => AppScaffold(
    title: 'Sephiri Password Manager',
    actions: [
      IconButton(
        tooltip: 'Password generator',
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => GeneratorScreen(container: widget.container),
          ),
        ),
        icon: const HeroIcon(HeroIcons.sparkles),
      ),
      IconButton(
        tooltip: 'Backup and restore',
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => BackupScreen(container: widget.container),
          ),
        ),
        icon: const HeroIcon(HeroIcons.arrowDownTray),
      ),
      IconButton(
        tooltip: 'Settings',
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => SettingsScreen(container: widget.container),
          ),
        ),
        icon: const HeroIcon(HeroIcons.cog6Tooth),
      ),
      IconButton(
        tooltip: 'Lock vault',
        onPressed: widget.container.session.lock,
        icon: const HeroIcon(HeroIcons.lockClosed),
      ),
      const SizedBox(width: 8),
    ],
    floatingActionButton: FloatingActionButton.extended(
      backgroundColor: const Color.fromARGB(255, 34, 44, 49),
      foregroundColor: Colors.white,
      onPressed: add,
      icon: const HeroIcon(HeroIcons.plus),
      label: const Text('New entry'),
    ),
    body: StreamBuilder<List<VaultEntryModel>>(
      stream: vault.watchEntries(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Could not load vault: ${snapshot.error}'));
        }
        final allEntries = snapshot.data ?? const <VaultEntryModel>[];
        final q = query.toLowerCase().trim();
        final filtered = allEntries.where((entry) {
          return q.isEmpty ||
              entry.title.toLowerCase().contains(q) ||
              entry.username.toLowerCase().contains(q) ||
              entry.url.toLowerCase().contains(q) ||
              entry.category.toLowerCase().contains(q) ||
              entry.tags.any((tag) => tag.toLowerCase().contains(q));
        }).toList();

        final groups = <String, List<VaultEntryModel>>{};
        for (final entry in filtered) {
          groups
              .putIfAbsent(
                entry.category.trim().isEmpty ? 'Other' : entry.category,
                () => [],
              )
              .add(entry);
        }
        final categories = groups.keys.toList()..sort();

        return LayoutBuilder(
          builder: (context, constraints) {
            final crossAxisCount = constraints.maxWidth >= 1100
                ? 4
                : constraints.maxWidth >= 680
                ? 3
                : 2;
            return ListView(
              padding: EdgeInsets.symmetric(
                horizontal: constraints.maxWidth > 1000 ? 36 : 18,
                vertical: 22,
              ),
              children: [
                Text(
                  'Your vault',
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  'All your important logins, organised in one secure place.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 22),
                TextField(
                  controller: searchController,
                  onChanged: (value) => setState(() => query = value),
                  decoration: const InputDecoration(
                    prefixIcon: Padding(
                      padding: EdgeInsets.all(14),
                      child: HeroIcon(HeroIcons.magnifyingGlass),
                    ),
                    hintText: 'Search titles, usernames, websites or tags',
                  ),
                ),
                const SizedBox(height: 18),
                PasswordHealthCard(report: health.analyze(allEntries)),
                const SizedBox(height: 22),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Categories',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    Text(
                      '${filtered.length} entries',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (categories.isEmpty)
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(28),
                      child: Column(
                        children: [
                          const HeroIcon(HeroIcons.key, size: 36),
                          const SizedBox(height: 12),
                          Text(
                            query.isEmpty
                                ? 'Your vault is empty'
                                : 'No matching entries',
                          ),
                          const SizedBox(height: 5),
                          Text(
                            query.isEmpty
                                ? 'Create your first login to get started.'
                                : 'Try a different search term.',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                  ),
                ...categories.map((category) {
                  final items = groups[category]!;
                  return Card(
                    clipBehavior: Clip.antiAlias,
                    child: ExpansionTile(
                      initiallyExpanded: true,
                      leading: const HeroIcon(HeroIcons.folder),
                      title: Text(
                        category,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      subtitle: Text(
                        '${items.length} ${items.length == 1 ? 'entry' : 'entries'}',
                      ),
                      childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
                      children: [
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: items.length,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: crossAxisCount,
                                crossAxisSpacing: 12,
                                mainAxisSpacing: 12,
                                mainAxisExtent: 142,
                              ),
                          itemBuilder: (context, index) {
                            final entry = items[index];
                            return EntryTile(
                              entry: entry,
                              onTap: () => edit(entry),
                              onDelete: () => _delete(entry),
                            );
                          },
                        ),
                      ],
                    ),
                  );
                }),
                const SizedBox(height: 90),
              ],
            );
          },
        );
      },
    ),
  );
}
