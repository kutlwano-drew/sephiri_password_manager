import 'package:flutter/material.dart';
import 'package:heroicons/heroicons.dart';

import '../../../models/vault_entry.dart';
import '../../../widgets/common/secure_text_field.dart';
import '../../../core/services/app_container.dart';
import '../../../core/services/vault_service.dart';

class EntryForm extends StatefulWidget {
  const EntryForm({
    super.key,
    required this.container,
    required this.vault,
    this.entry,
  });

  final AppContainer container;
  final VaultService vault;
  final VaultEntryModel? entry;

  @override
  State<EntryForm> createState() => _EntryFormState();
}

class _EntryFormState extends State<EntryForm> {
  final title = TextEditingController();
  final username = TextEditingController();
  final password = TextEditingController();
  final url = TextEditingController();
  final notes = TextEditingController();
  final tagInput = TextEditingController();

  final List<String> entryTags = [];

  String category = 'Login';
  bool favorite = false;
  bool busy = false;

  @override
  void initState() {
    super.initState();

    final entry = widget.entry;

    if (entry != null) {
      title.text = entry.title;
      username.text = entry.username;
      password.text = entry.password;
      url.text = entry.url;
      notes.text = entry.notes;

      entryTags.addAll(entry.tags);

      category = entry.category;
      favorite = entry.favorite;
    }
  }

  @override
  void dispose() {
    title.dispose();
    username.dispose();
    password.dispose();
    url.dispose();
    notes.dispose();
    tagInput.dispose();

    super.dispose();
  }

  void addTag([String? value]) {
    final tag = (value ?? tagInput.text).trim();

    if (tag.isEmpty) return;

    final exists = entryTags.any(
      (existing) => existing.toLowerCase() == tag.toLowerCase(),
    );

    if (!exists) {
      setState(() {
        entryTags.add(tag);
      });
    }

    tagInput.clear();
  }

  void removeTag(String tag) {
    setState(() {
      entryTags.remove(tag);
    });
  }

  void handleTagInput(String value) {
    if (!value.contains(',')) return;

    final parts = value.split(',');
    final completedTags = parts.sublist(0, parts.length - 1);
    final remaining = parts.last;

    for (final part in completedTags) {
      final tag = part.trim();

      if (tag.isNotEmpty) {
        final exists = entryTags.any(
          (existing) => existing.toLowerCase() == tag.toLowerCase(),
        );

        if (!exists) {
          entryTags.add(tag);
        }
      }
    }

    tagInput.value = TextEditingValue(
      text: remaining,
      selection: TextSelection.collapsed(offset: remaining.length),
    );

    setState(() {});
  }

  Future<void> save() async {
    if (busy) return;

    // Include the last tag even if no comma was entered.
    final remainingTag = tagInput.text.trim();

    if (remainingTag.isNotEmpty) {
      final exists = entryTags.any(
        (existing) => existing.toLowerCase() == remainingTag.toLowerCase(),
      );

      if (!exists) {
        entryTags.add(remainingTag);
      }

      tagInput.clear();
    }

    setState(() => busy = true);

    try {
      await widget.vault.save(
        VaultEntryModel(
          id: widget.entry?.id,
          title: title.text.trim(),
          username: username.text.trim(),
          password: password.text,
          url: url.text.trim(),
          notes: notes.text,
          category: category,
          tags: List<String>.from(entryTags),
          favorite: favorite,
        ),
      );

      if (mounted) {
        Navigator.pop(context);
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Could not save entry: $error')));
      }
    } finally {
      if (mounted) {
        setState(() => busy = false);
      }
    }
  }

  Widget _fieldPair({
    required double width,
    required Widget first,
    required Widget second,
  }) {
    if (width < 620) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [first, const SizedBox(height: 20), second],
      );
    }

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(child: first),
        const SizedBox(width: 16),
        Expanded(child: second),
      ],
    );
  }

  InputDecoration _decoration(String label, HeroIcons icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Padding(
        padding: const EdgeInsets.all(14),
        child: HeroIcon(icon),
      ),
    );
  }

  Widget _buildTagsField() {
    final theme = Theme.of(context);

    return InputDecorator(
      decoration: _decoration('Tags', HeroIcons.tag),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (entryTags.isNotEmpty) ...[
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: entryTags.map((tag) {
                return InputChip(
                  label: Text(tag),
                  onDeleted: () => removeTag(tag),
                  visualDensity: VisualDensity.compact,
                  deleteIcon: const HeroIcon(HeroIcons.xMark, size: 16),
                );
              }).toList(),
            ),
            const SizedBox(height: 6),
          ],
          TextField(
            controller: tagInput,
            onChanged: handleTagInput,
            onSubmitted: (_) => addTag(),
            decoration: InputDecoration(
              hintText: entryTags.isEmpty
                  ? 'Type a tag and enter comma'
                  : 'Add another tag...',
              border: InputBorder.none,
              isDense: true,
              hintStyle: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) => Form(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            _fieldPair(
              width: constraints.maxWidth,
              first: TextFormField(
                controller: title,
                decoration: _decoration('Title', HeroIcons.identification),
              ),
              second: TextFormField(
                controller: username,
                decoration: _decoration('Username / email', HeroIcons.user),
              ),
            ),

            const SizedBox(height: 22),

            _fieldPair(
              width: constraints.maxWidth,
              first: SecureTextField(
                controller: password,
                showStrength: true,
                onCopy: () async {
                  if (password.text.isEmpty) return;

                  await widget.container.clipboard.copySensitive(password.text);

                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Password copied. Clipboard clears after 30 seconds.',
                        ),
                      ),
                    );
                  }
                },
              ),
              second: TextFormField(
                controller: url,
                keyboardType: TextInputType.url,
                decoration: _decoration('Website URL', HeroIcons.globeAlt),
              ),
            ),

            const SizedBox(height: 22),

            _fieldPair(
              width: constraints.maxWidth,
              first: DropdownButtonFormField<String>(
                initialValue: category,
                decoration: _decoration(
                  'Category / social',
                  HeroIcons.squares2x2,
                ),
                items:
                    const [
                          'Login',
                          'Email',
                          'Banking',
                          'Social',
                          'Facebook',
                          'Instagram',
                          'X / Twitter',
                          'TikTok',
                          'LinkedIn',
                          'Snapchat',
                          'Reddit',
                          'Pinterest',
                          'YouTube',
                          'WhatsApp',
                          'Discord',
                          'GitHub',
                          'Twitch',
                          'Spotify',
                          'Shopping',
                          'Work',
                          'Wi-Fi',
                          'License',
                          'Secure note',
                          'Other',
                        ]
                        .map(
                          (value) => DropdownMenuItem(
                            value: value,
                            child: Text(value),
                          ),
                        )
                        .toList(),
                onChanged: (value) {
                  if (value != null) {
                    setState(() => category = value);
                  }
                },
              ),
              second: _buildTagsField(),
            ),

            const SizedBox(height: 24),

            Text(
              'Secure notes',
              style: Theme.of(context).textTheme.titleMedium,
            ),

            const SizedBox(height: 8),

            TextFormField(
              controller: notes,
              minLines: 5,
              maxLines: 8,
              decoration: _decoration('Private notes', HeroIcons.documentText),
            ),

            const SizedBox(height: 10),

            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: const HeroIcon(HeroIcons.star),
              title: const Text('Favorite'),
              value: favorite,
              onChanged: (value) {
                setState(() => favorite = value);
              },
            ),

            const SizedBox(height: 14),

            Center(
              child: FractionallySizedBox(
                widthFactor: 0.45,
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                    foregroundColor: Colors.white,
                    minimumSize: const Size(0, 46),
                  ),
                  onPressed: busy ? null : save,
                  icon: const HeroIcon(HeroIcons.check, color: Colors.white),
                  label: Text(
                    busy ? 'Saving…' : 'Save entry',
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
