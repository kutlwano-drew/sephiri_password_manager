class VaultEntryModel {
  const VaultEntryModel({this.id, required this.title, required this.username, required this.password, this.url = '', this.notes = '', this.category = 'Login', this.tags = const [], this.favorite = false});
  final String? id;
  final String title;
  final String username;
  final String password;
  final String url;
  final String notes;
  final String category;
  final List<String> tags;
  final bool favorite;
}
